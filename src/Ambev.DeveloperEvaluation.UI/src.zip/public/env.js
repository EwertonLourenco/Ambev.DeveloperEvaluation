// default para DEV local (ng serve)
window.__env = {
  API_BASE_URL: "http://localhost:8080" // ajuste se sua API dev for outra
};
